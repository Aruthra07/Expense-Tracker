export const API_URL = "https://wallet-api-cxqp.onrender.com/api";
// export const API_URL = "http://localhost:5001/api";
